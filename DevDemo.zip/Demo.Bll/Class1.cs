﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo.Bll
{
    public class Class1
    {
        /// <summary>
        /// 校验用户名密码是否正确
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="userPwd"></param>
        /// <returns></returns>
        Class1 dal = new Class1();
        public bool UserLogin(string userName, string userPwd, out string msg)
        {

            UserInfo userInfo = dal.GetUserInfoByName(userName);
            if (userInfo != null)
            {
                if (userInfo.Pwd == userPwd)
                {
                    msg = "Login Succeed!!";
                    return true;
                }
                else
                {
                    msg = "Error Password!!";
                    return false;
                }
            }
            else
            {
                msg = "None Exist User!!";
                return false;
            }
        }
    }
}
