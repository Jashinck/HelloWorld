﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPMind
{
    class Program
    {
        static void Main(string[] args)
        {

            RealDuck rd = new RealDuck();
            XPDuck xd = new XPDuck();
            rd.Swim();
            xd.Swim();

            Duck[] ducks = { rd, xd };
            foreach(Duck duck in ducks)
            {
                duck.Swim();
            }
            IBark[] bark = { rd, xd };
            foreach(IBark bar in bark)
            {
                bar.Bark();
            }
        }
    }

    class Duck
    {
        public void Swim()
        {
            Console.WriteLine("Duck Can Swim.");
        }


    }

    interface IBark
    {
        void Bark();
      
    }

    class RealDuck:Duck,IBark
    {
        public void Bark()
        {
            Console.WriteLine("RealDucm Guagua Loud");
        }
    }

    class XPDuck:Duck,IBark
    {
        void IBark.Bark()
        {
            Console.WriteLine("XipDuck JIji Loud");
        }
    }
}
