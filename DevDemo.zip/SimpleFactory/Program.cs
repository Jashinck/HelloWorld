﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleFactory
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Please input: 1,2,3 For Card Category");
            string input = Console.ReadLine();
            Card card = Factory.GetCard(input);
            if(card!=null)
            {
                card.Dosomething();
            }
            else
            {
                Console.WriteLine("No Card");
            }
        }
    }


    abstract class Card
    {
        public abstract void Dosomething();
    }

    class BankCard:Card
    {
        public override void Dosomething()
        {
            Console.WriteLine("BankCard Get Cash");
        }
    }

    class FoodCard:Card
    {
        public override void Dosomething()
        {
            Console.WriteLine("FoodCard Get Food");
        }
    }

    class DoorCard:Card
    {
        public override void Dosomething()
        {
            Console.WriteLine("DoorCard Get House");
        }
    }

    class Factory
    {
        public static Card GetCard(string input)
        {
            Card card = null;
            switch(input)
            {
                case "1":
                    card = new BankCard();
                    break;
                case "2":
                    card = new FoodCard();
                    break;
                case "3":
                    card = new DoorCard();
                    break;

            }

            return card;
        }
    }
}
