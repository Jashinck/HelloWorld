﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Demo.Model;

namespace Demo.Dal
{
    public class Class1
    {
        /// <summary>
        /// 根据用户名找人
        /// </summary>
        /// <param name="userName"></param>
        public Class1 GetUserInfoByName(string userName)
        {
            string sql = "select * from UserInfo where LoginUserName=@LoginUserName";
            DataTable da = SqLiteHelper.GetDataTable(sql, new SQLiteParameter("@LoginUserName", userName));
            UserInfo userInfo = null;
            if (da.Rows.Count > 0)
            {
                userInfo = new UserInfo();
                LoadEntity(userInfo, da.Rows[0]);
            }
            return userInfo;
        }
        //将行中的数据赋值给实体中的属性
        private void LoadEntity(UserInfo userInfo, DataRow row)
        {
            userInfo.UserId = Convert.ToInt32(row["UserId"]);
            userInfo.LoginUserName = row["LoginUserName"].ToString();
            userInfo.Pwd = row["Pwd"].ToString();
        }
    }
}
