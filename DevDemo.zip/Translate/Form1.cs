﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Translate
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Dictionary<string, string> dic = new Dictionary<string, string>();
        private void button1_Click(object sender, EventArgs e)
        {
            if(dic.ContainsKey(txtEnglish.Text.Trim()))
            {
                txtChinese.Text = dic[txtEnglish.Text.Trim()];
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] lines = File.ReadAllLines(@"C:\DevCode\Like.txt", Encoding.Default);
            for (int i = 0; i < lines.Length; i++)
            {
                string[] temp = lines[i].Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                string chinese = string.Empty;
                //把除了第一项的英文单词  后面所有的中文解释的累加给chinese
                //temp[i]  abandon   v.抛弃 放弃
                for (int j = 1; j < temp.Length; j++)
                {
                    chinese += temp[j];
                }

                if (!dic.ContainsKey(temp[0]))
                {
                    dic.Add(temp[0], chinese);
                }
                else
                {
                    dic[temp[0]] += chinese;
                }
            }
        }
    }
}
